% Homework item 1:
 smngLabMembers(2).lab = 'BLAB'
 smngLabMembers(2).phdYear = 2017
 smngLabMembers(2).smngYears = 2017:2020

% Homework item 2:
sarahsLastYear = smngLabMembers(2).smngYears(end);

% Homework item 3:
cellArray = expt.conds
doubleArray = expt.bTestMode

% Homework item 4:
formant2 = formants(:,2);
formant3 = formants(30,3);

% Homework item 5;
mackenzieStruct = struct('letters', {'a','b','c'}, 'numbers', [1,2,3],'weight',[132,165,177])

