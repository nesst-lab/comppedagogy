% Homework item 1
    % setting a for loop that runs every trial between the first and last
    
% Homework item 2
    % if the current trial is equal to one with a break
    
% Homework item 3
    % There is a list containing the predetermined words
    
% Homework item 4
    % 